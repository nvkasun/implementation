terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "5.91.0"
    }
  }

  backend "s3" {}

  required_version = ">= 1.5.0"
}

provider "aws" {
}